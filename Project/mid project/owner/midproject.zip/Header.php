<center><br><nav style="font-size: 27px; background-color:#f2f2f2; " >
<a style="text-decoration: none;" href="../view/home.php">HOME &nbsp;&nbsp;</a>

<a style="text-decoration: none;" href="../view/viewselfinfo.php">Viewselfinfo&nbsp;&nbsp;</a>
<a style="text-decoration: none;" href="../view/addcustomer.php">Addcustomer&nbsp;&nbsp;</a>
<a style="text-decoration: none;" href="../view/viewordersummary.php">Viewordersummary&nbsp;&nbsp;</a>
<a style="text-decoration: none;" href="../view/viewcustomerlist.php">Viewcustomerlist&nbsp;&nbsp;</a>
<a style="text-decoration: none;" href="../view/viewbookinglist.php">Viewbookinglist&nbsp;&nbsp;</a>

<a style="text-decoration: none;" href="../view/passreset.php">PasswordReset</a>
<a style="text-decoration: none;" href="../controller/action_requesttoremovebook.php">RemoveBooking</a>
<a style="text-decoration: none;" href="../controller/action_removeorder.php">RemoveOrder</a>
<a style="text-decoration: none;" href="../controller/action_updateselfinfo.php">UpdateInfo</a>
<a style="text-decoration: none;" href="../view/signup.php">SignUp</a>
<a style="text-decoration: none;" href="../controller/action_logout.php">Logout</a>
</nav></br></center>