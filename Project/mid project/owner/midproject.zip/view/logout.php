<!Doctype html>
<html>
<head>

</head>

<body>

<center><h1>logout</h1></center>
<div class="form">
<form action = "" method = "post">
<center>
<table>
<tr>
<td></td>
<td><input type="Submit" value="logout" name="submit"></td>
</tr>

</table>


</center>


</body>
</html>