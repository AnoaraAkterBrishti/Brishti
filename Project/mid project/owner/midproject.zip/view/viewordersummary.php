<!DOCTYPE html>
<html>
<title>Customer order</title>
<body>
<?php include('Header.php'); ?>
<center>
<h1> Order Summary </h1>

<table  border= "1"  cellpadding= "25" >
<tr>
	<th>Customer No</th>
	<th>Product Name</th>
	<th>Category</th>
	<th>Sub-Category</th>
	<th>Quantity</th>
	<th>Price</th>
	
</tr>
<tr>
<td>1</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td>1</td>
<td>1</td>

</tr>
</table>
</center>
<br>
<br>
<?php include('Footer.php'); ?>
</body>
</html>