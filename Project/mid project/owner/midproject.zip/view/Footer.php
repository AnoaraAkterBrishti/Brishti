<center><footer style="background-color:blue;" >
<br><p> OWNER PAGE </p><br>
</footer></center>