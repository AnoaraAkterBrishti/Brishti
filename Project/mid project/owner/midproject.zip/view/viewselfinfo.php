<!DOCTYPE html>
<html>
<title> My Profile</title>
<body>
<?php include('Header.php'); ?>
<center>
<h2> View Profile</h2>

<table>
	<tr> 
		<td><b> Username: </b></td>
		<td> Owner</td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b> Full Name: </b></td>
		<td> Anoara Akter brishti </td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b> Email Address: </b></td>
		<td> bristyakhter007@gmail.com </td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b> Phone Number: </b></td>
		<td> 013XXXXXXXX </td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b> Gender: </b></td>
		<td> Female </td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b> Birthday: </b></td>
		<td> 23/03/1999 </td>
	</tr>
	<tr><td></td><td></td></tr>
	<tr> 
		<td><b>Present Address: </b></td>
		<td> 20,Rajarbag,Dhaka </td>
	</tr>
	<tr><td></td><td></td></tr>
</table></center>
<br>
<br>
<?php include('Footer.php'); ?>
</body>
</html>